#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "IRCam_lib.h"

static short nRefTemp1 = 2047; // 4803
static short nRefTemp2 = 2247; // 4804
static short nRefTemp3 = 22; // 4805

static float convert(short, short, short, short);
static float after_convert(short, short, short, short);
static short search_max(void);
static float calibration(float);
static bool RaiderData(char*);

static float temp[80][60];
static float actual_temp[80][60];
static float bodytemp[60][60];
static float blackbodytemp[20][60];
// store raw data.
static short gs_raw_data[80][60];
static float m_fCalibration = 0.0;
static float m_fOffsetDelta = 2.0;
static float m_fBlackbodyDelta = 0.0;
static float m_fCorectDistanceDelta = 0.0;
static float m_fAutoAlarmTempValue = 0.0;

static bool m_bPushAlarmOnOff = true;

typedef struct coordi {
	int x;
	int y;
} t_coordi;

static t_coordi blackbody_max(void);
static t_coordi cam_xy;

int SK_IRCAM_init(void)
{
	calibration(30);	
	return 0;
}

float SK_IRCAM_setCalibrationTemp(float fCalibrationTemp)
{
	float fMaxVal = search_max();

	m_fCalibration = fCalibrationTemp - (fMaxVal - m_fBlackbodyDelta - m_fCalibration);

	return m_fCalibration;
}

union Uint16With2Byte {
	unsigned short Data;
	unsigned char  byte[2];
} mDataConvertion;

short ChangeTemp(short nTempValue, unsigned char* buf)
{
	short         nReturn;
	unsigned char  nCrcData;

	short nValue = 0;
	nValue |= (((short)buf[1]) << 8) & 0xff00;
	nValue |= (((short)buf[0])) & 0xff;

	return nValue;
}

short SK_IRCAM_getBodyTemp(unsigned char* raw_data, int len) //, char* pRaiderData)
{
	unsigned short raw_data2[15000] = { 0, };
	int nC = 0;
	unsigned char  nIData[50] = { 0, };
	for (int n = 0; len > n; n++){
		if ((n % 2) == 0) {
			mDataConvertion.byte[1] = raw_data[n];
		}
		else {
			mDataConvertion.byte[0] = raw_data[n];
		}
		raw_data2[nC] = ChangeTemp(raw_data[n], mDataConvertion.byte);
		nC++;
	}

	memcpy(gs_raw_data, raw_data2, nC);

	//printf("%s, %d\n", __FUNCTION__, __LINE__);

	for (int i = 0; i < 80; i++)
	{
		for (int j = 0; j < 60; j++)
		{
			temp[i][j] = convert(gs_raw_data[i][j], nRefTemp1, nRefTemp2, nRefTemp3);
		}
	}

	//printf("%s, %d\n", __FUNCTION__, __LINE__);

	//for (int i=0; i<20; i++) 
	{
		//for (int j=0; j<60; j++) 
		{
			cam_xy = blackbody_max();
		}
	}

	//printf("%s, %d\n", __FUNCTION__, __LINE__);

	for (int i = 0; i < 80; i++)
	{
		for (int j = 0; j < 60; j++)
		{
			actual_temp[i][j] = after_convert(temp[i][j], nRefTemp1, nRefTemp2, nRefTemp3);
		}
	}

	//printf("%s, %d\n", __FUNCTION__, __LINE__);

	for (int i = 20; i < 80; i++)
	{
		for (int j = 0; j < 60; j++) {

			bodytemp[i][j] = actual_temp[i][j];
		}
	}
	
	for (int i = 0; i < 20; i++)
	{
		for (int j = 0; j < 60; j++)
		{
			blackbodytemp[i][j] = actual_temp[i][j];
			
		}
	}

	//printf("%s, %d\n", __FUNCTION__, __LINE__);

	short bodytemp_max = search_max();

	//printf("%s, %d\n", __FUNCTION__, __LINE__);
	bodytemp_max = bodytemp_max + m_fCorectDistanceDelta;

	//RaiderData(pRaiderData);
	printf("2. %.2d, %.2f, %.2f \n", bodytemp_max, m_fBlackbodyDelta, m_fCalibration);

	return bodytemp_max;
}

static float convert(short nPixelValue, short nRefTemp1, short nRefTemp2, short nRefTemp3)
{
	float fCodePerOneDegree = (float)(nRefTemp2 - nRefTemp1);
	float nSlope = 20.0f / fCodePerOneDegree;
	float nReturn = (float)(nPixelValue - nRefTemp1);

	if ((nRefTemp3 > 150)) {
		nReturn = (nSlope * nReturn) + 25;
	}
	else {
		nReturn = (nSlope * nReturn) + nRefTemp3;
	}

	return nReturn = nReturn * 0.98f;

}

static float after_convert(short nReturn, short nRefTemp1, short nRefTemp2, short nRefTemp3)
{
	int x = cam_xy.x;
	int y = cam_xy.y;

	float fBlackbodyPointTemp = temp[x][y];
	m_fBlackbodyDelta = fBlackbodyPointTemp - 40.0;

	//float realtemp = nReturn + m_fBlackbodyDelta + m_fCalibration + m_fCorectDistanceDelta;

	return nReturn + m_fBlackbodyDelta + m_fCalibration;
}

static float calibration(float fCalibrationTemp)
{
	float fMaxVal = search_max();

	m_fCalibration = fCalibrationTemp - (fMaxVal - m_fBlackbodyDelta - m_fCalibration);
	printf("%.2f, %.2f, %.2f, %.2f \n", fCalibrationTemp, fMaxVal, m_fBlackbodyDelta, m_fCalibration);

	m_fAutoAlarmTempValue = fMaxVal + m_fBlackbodyDelta + m_fCalibration + m_fOffsetDelta;

	return m_fCalibration;
}

static float offset(bool bSymbol, float fValTemp)
{
	/*if (bSymbol == 0)
	{
		m_fOffsetDelta = m_fOffsetDelta - fValTemp;
	}
	else {
		m_fOffsetDelta = m_fOffsetDelta + fValTemp;
	}*/
	if (bSymbol == 0)
	{
		m_fOffsetDelta = -fValTemp;
	}
	else {
		m_fOffsetDelta = fValTemp;
	}
	return m_fOffsetDelta;
}

static short search_max(void)
{
	short m_fMaxVal = 0;

	for (int i = 20; i < 80; i++)
		for (int j = 0; j < 60; j++)
		{
			if (bodytemp[i][j] > m_fMaxVal) {
				m_fMaxVal = bodytemp[i][j];
			}
		}

	return m_fMaxVal;
}

static t_coordi blackbody_max(void)
{
	short m_fMaxVal = 0;
	int x = 0;
	int y = 0;
	t_coordi tmp;

	tmp.x = 0;
	tmp.y = 0;

	for (int i = 0; i < 20; i++)
	{
		for (int j = 0; j < 60; j++)
		{
			if (blackbodytemp[i][j] > m_fMaxVal) {
				m_fMaxVal = blackbodytemp[i][j];
				tmp.x = i;
				tmp.y = j;
			}
		}
	}

	printf("blackbody_max, x:%d, y:%d\n", tmp.x, tmp.y);
	return tmp;
}


static bool RaiderData(char* pRaiderData)
{

	char* pData = pRaiderData;
	char const* Data = "no One";

	if (strstr(pData, Data) != NULL)
	{
		m_fCalibration = 0.0;
		m_bPushAlarmOnOff = false;
		return false;
	}

	Data = "moving";
	if (strstr(pData, Data) != NULL)
	{
		//return false;
	}

	if (m_fCalibration == 0.0)
	{
		calibration(30);
	}

	m_bPushAlarmOnOff = true;

	char* ptr = strstr(pData, "Distance");

	char szDistance[5] = " ";
	if (ptr != NULL) {
		ptr = strchr(ptr, ':');
		ptr = strchr(ptr, ' ');
	}
	else {
		return false;
	}
	char szChar;
	int n = 0, nf = 0;;
	while (ptr != NULL)
	{
		if (ptr == NULL) {
			n = n + 1;
			continue;
		}
		else if (ptr != NULL) {
			szChar = ptr[nf];
			if (szChar == 'm') {
				break;
			}
			else if (szChar == ' ') {
				nf = nf + 1;
				continue;
			}
			else {
				szDistance[n] = szChar;
			}
			nf = nf + 1;
			n = n + 1;
		}
		if (n == 5)
			break;
	}

	float fDistance = atof(szDistance);
	if (fDistance > 0.0) {
		m_fCorectDistanceDelta = fDistance;
	}


	if (m_fAutoAlarmTempValue >= search_max())
	{
		//Alarm App Push function
	}


	return true;
}