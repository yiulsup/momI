#include "p2p_client.h"

extern int g_login_flag;
extern int g_userChn_flag;

int main()
{
	int flag = 0, user_flag = 0;
	unsigned int count = 0;
	p2p_client_initial("00023323");
	p2p_client_set_local_addr("192.168.1.113");
	p2p_client_start("120.79.60.230", 6000, "00018775", "admin");
	p2p_client_start_live();

	while(1)
	{
		if(g_login_flag)
		{
			count++;

			if(!flag)
			{
				flag = 1;
				char strJson[512];
				sprintf(strJson, "{\"cmd\":\"%s\",\"cid\":%d,\"channel\":%d}", "get_device_info", 0, 0);
				p2p_client_send_json(strJson);

				p2p_client_start_userChannel();
			}

			if(g_userChn_flag && !user_flag && count > 100)
			{
				user_flag = 1;
				
				printf("p2p_client_test_userChannel....\n");

				p2p_client_test_userChannel();
				sleep(5);
				p2p_client_test_userChannel();
			}
		}

		usleep(10 * 1000);
	}

	p2p_client_stop_userChannel();

	p2p_client_clean();
	return 0;
}