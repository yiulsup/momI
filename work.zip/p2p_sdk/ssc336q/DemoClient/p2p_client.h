#ifndef P2P_CAMERA_H
#define P2P_CAMERA_H

int p2p_client_initial(char* szDeviceID);
int p2p_client_clean();
int p2p_client_set_local_addr(char* szLocalIP);
int p2p_client_start(char* szServerIP, int nServerPort, char* szRemoteDeviceID, char* szRemoteDevicePassword);
int p2p_client_stop();
int p2p_client_start_live();
int p2p_client_stop_live();
int p2p_client_get_device_info();
int p2p_client_send_json(char* szJsonData);

#endif

