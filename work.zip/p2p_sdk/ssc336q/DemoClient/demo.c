#include "p2p_client.h"

int main()
{
	p2p_client_initial("00023323");
	p2p_client_set_local_addr("192.168.1.113");
	p2p_client_start("120.79.60.230", 6000, "00018776", "admin");
	p2p_client_start_live();
	while(1)
	{
		usleep(10 * 1000 * 1000);
	}
	p2p_client_clean();
	return 0;
}