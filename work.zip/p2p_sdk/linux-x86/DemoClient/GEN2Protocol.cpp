#define __CV_GEN2_PROTOCOL_H

#include <stdlib.h>
#include <stdio.h>
#include "GEN2Protocol.h"

#define CONFIG_DEBUG 		0

#if CONFIG_DEBUG
#define DBG_ERR(x...)		perror(x)
#define DBG_NET(x...)		printf(x)
#define DBG(x...)			printf(x)
#else
#define DBG_ERR(x...)
#define DBG_NET(x...)
#define DBG(x...)
#endif

extern int SK_IRCAM_SendCommand(unsigned char  * cmd, int len);

static int gs_total_cmd;
static unsigned char mTW3530Protocol[30][20];

static void cvGEN2Protocol_CommandInit(void)
{
	unsigned int  nj, ni;
	unsigned char nTW3530Protocol[][10] = {
		//// 0    1     2     3     4     5     6     7     8     9 
		// change fps
		{ 0x02, 0x00, 0x04, 0x01, 0x01, 0x00,   30, 0x03, 0xFF, 0x00 }, //  0
		{ 0x02, 0x00, 0x04, 0x01, 0x01, 0x00,   20, 0x03, 0xFF, 0x00 }, //  1
		{ 0x02, 0x00, 0x04, 0x01, 0x01, 0x00,   15, 0x03, 0xFF, 0x00 }, //  2
		{ 0x02, 0x00, 0x04, 0x01, 0x01, 0x00,   12, 0x03, 0xFF, 0x00 }, //  3
		{ 0x02, 0x00, 0x04, 0x01, 0x01, 0x00,   10, 0x03, 0xFF, 0x00 }, //  4
		{ 0x02, 0x00, 0x04, 0x01, 0x01, 0x00,    6, 0x03, 0xFF, 0x00 }, //  5
		{ 0x02, 0x00, 0x04, 0x01, 0x01, 0x00,    5, 0x03, 0xFF, 0x00 }, //  6
		{ 0x02, 0x00, 0x04, 0x01, 0x01, 0x00,    2, 0x03, 0xFF, 0x00 }, //  7
		{ 0x02, 0x00, 0x04, 0x01, 0x01, 0x00,    1, 0x03, 0xFF, 0x00 }, //  8
		// start output
		{ 0x02, 0x00, 0x04, 0x02, 0x01, 0x00, 0x01, 0x03, 0xFF, 0x00 }, // 9
		// start image output(temperature)
		{ 0x02, 0x00, 0x04, 0x02, 0x01, 0x01, 0x01, 0x03, 0xFF, 0x00 }, // 10 
		// stop image output
		{ 0x02, 0x00, 0x04, 0x02, 0x01, 0x00, 0x00, 0x03, 0xFF, 0x00 }, // 11
		//
		{ 0x02, 0x00, 0x04, 0x00, 0x01, 0x34, 0x12, 0x03, 0xFF, 0x00 },  // 12
		// Set Correction of Image
		{ 0x02, 0x00, 0x04, 0x1A, 0x01, 0x00, 0x01, 0x03, 0xFF, 0x00 }  // 13
	}; 

	gs_total_cmd = sizeof(nTW3530Protocol)/sizeof(nTW3530Protocol[0]);

	for ( nj = 0 ; nj < gs_total_cmd ; nj++ ) {
		for ( ni = 0 ; ni < 10 ; ni++ ) {
			mTW3530Protocol[nj][ni] = nTW3530Protocol[nj][ni];
		}

		mTW3530Protocol[nj][8] = 0x00;

		for ( ni = 1 ; ni <= 6 ; ni++ ) {
			mTW3530Protocol[nj][8] ^= nTW3530Protocol[nj][ni];
		}
	}	
}

int cvGEN2Protocol_SendCommand(int cmd)
{
	if(cmd >= 0 && cmd < gs_total_cmd)
	{
		return SK_IRCAM_SendCommand(&mTW3530Protocol[cmd][0], 9);	
	}
}

void cvGEN2Protocol_Initial(void)
{
	unsigned int ni;

	cvGEN2Protocol_CommandInit();

	cvGEN2Protocol.SWVersionType = 5; //// New Version : After 2022.11.25 :::::  Old Version = 4 : Before 2022.11.01 

	cvGEN2Protocol.ClassStartFlag = Def_TRUE;

	cvGEN2Protocol.ClassErrorFlag = Def_FALSE;

	cvGEN2Protocol.StepAnalysisFlag  = DefGEN2PROTOCOL_STEP1_CHECK_STX;
	cvGEN2Protocol.CommandStatusFlag = DefGEN2PROTOCOL_COMMAND_CHECK_STANDBY;

	cvGEN2Protocol.CheckSumSelf     = 0x00;
	cvGEN2Protocol.CheckSumFromGEN2 = 0x00;

	cvGEN2Protocol.Length    = 0;

	cvGEN2Protocol.Command   = 0;
	
	cvGEN2Protocol.DataCount = 0;
	for (ni = 0; ni < DefGEN2PROTOCOL_DATA_MAX_SIZE; ni++)
	{
		cvGEN2Protocol.Data[ni] = 0;
	}

	cvGEN2Image.FrameRate = 0;
	cvGEN2Image.XSize = 0;
	cvGEN2Image.YSize = 0;
	cvGEN2Image.XSize = 0;


	cvGEN2Image.ImageReceivedFalg = 0;
	for (ni = 0; ni < 5000; ni++)
	{
		cvGEN2Image.Image[ni] = 0;
	}
	cvGEN2Image.ImageCount  = 0;
	cvGEN2Image.ImageLength = 0;

	cvGEN2Image.ImageMin = 4096;
	cvGEN2Image.ImageMax =    0;

	cvGEN2Image.ImageMaxPoint  = 0;
	cvGEN2Image.ImageMaxPointX = 0;
	cvGEN2Image.ImageMaxPointY = 0;
	cvGEN2Image.ImageMinPoint  = 0; 
	cvGEN2Image.ImageMinPointX = 0;
	cvGEN2Image.ImageMinPointY = 0;

	cvGEN2Image.PRODUCTINFORFlag = 0;
	for (ni = 0; ni < 1024; ni++)
	{
		cvGEN2Image.PRODUCTINFOR[ni] = 0;
	}
	cvGEN2Image.PRODUCTINFORCount = 0;

	for (ni = 0; ni < 6; ni++)
	{
		cvGEN2Image.PRODUCTINFORHWVER[ni] = '\0';
		cvGEN2Image.PRODUCTINFORSWVER[ni] = '\0';
	}

	for (ni = 0; ni < 21; ni++)
	{
		cvGEN2Image.INLINENumber[ni] = '\0';
	}

	cvGEN2Image.OperationMode = 0;
	cvGEN2Image.ShutterStatus = Def_SHUTTER_OPEN;
}

/*
unsigned char            FrameRate;
unsigned short           XSize;
unsigned short           YSize;

float                    VCM_F;
float                    TEMP_F;

unsigned short           VCM;
float                    VCMFloat;

short                    TEMPSENSOR;
float                    TEMPSENSORFloat;

short                    TEMPMCU;
short                    TEMPBOARD;

unsigned short           ImageReceivedFalg;

unsigned short           Image[5000];
unsigned short           ImageLength;
unsigned short           ImageCount;

unsigned short           ImageMax;
unsigned short           ImageMin;

unsigned short           ImageMaxPoint;
unsigned short           ImageMaxPointX;
unsigned short           ImageMaxPointY;
unsigned short           ImageMinPoint;
unsigned short           ImageMinPointX;
unsigned short           ImageMinPointY;


unsigned char            PRODUCTINFORFlag;

unsigned char            PRODUCTINFOR[1024];
unsigned short           PRODUCTINFORCount;

unsigned char            INLINENumber[21];

unsigned short           PRODUCTINFORHWVER;
unsigned short           PRODUCTINFORSWVER;

unsigned char            OperationMode;
unsigned char            ShutterStatus;
*/
char cvGEN2Protocol_Analysis(unsigned char* nReceivedData, unsigned short nReceivedLength)
{
	char           nReturn;
	unsigned short ni, nPosXXX, nPosYYY;;
	unsigned char  nByteData;

	nReturn = -1;

	for (ni = 0; ni < nReceivedLength; ni++) {
		nByteData = nReceivedData[ni];
		
		switch (cvGEN2Protocol.StepAnalysisFlag) 
		{
			case DefGEN2PROTOCOL_STEP1_CHECK_STX :
				if (nByteData == DefGEN2PROTOCOL_CODE_STX) {
					DBG("1-get start flag\n");

					cvGEN2Protocol.StepAnalysisFlag  = DefGEN2PROTOCOL_STEP2_GET_LENGTH0;

					cvGEN2Protocol.CommandStatusFlag = DefGEN2PROTOCOL_COMMAND_GETTING_DATA;

					cvGEN2Protocol.CheckSumSelf = 0x00;

					cvGEN2Protocol.Length       = 0;
					cvGEN2Protocol.DataCount    = 0;

					cvGEN2Image.ImageCount  = 0;
					cvGEN2Image.ImageLength = 0;
				}
				else {
					cvGEN2Protocol.StepAnalysisFlag  = DefGEN2PROTOCOL_STEP1_CHECK_STX;
					cvGEN2Protocol.CommandStatusFlag = DefGEN2PROTOCOL_COMMAND_CHECK_STANDBY;
				}

				break;
			case DefGEN2PROTOCOL_STEP2_GET_LENGTH0:
				DBG("get length 0\n");
				cvGEN2Protocol.CheckSumSelf ^= nByteData;				
				cvGEN2Protocol.StepAnalysisFlag++;

				Uint16To2Byte.Data = 0x0000;

				Uint16To2Byte.byte[1] = nByteData;
				break;
			case DefGEN2PROTOCOL_STEP2_GET_LENGTH1:				
				cvGEN2Protocol.CheckSumSelf ^= nByteData;
				cvGEN2Protocol.StepAnalysisFlag++;

				Uint16To2Byte.byte[0] = nByteData;

				cvGEN2Protocol.Length = Uint16To2Byte.Data;
				DBG("DefGEN2PROTOCOL_STEP2_GET_LENGTH1, len:%d\n", cvGEN2Protocol.Length);
				break;
			case DefGEN2PROTOCOL_STEP3_GET_COMMAND0:
				DBG("get command 0\n");
				cvGEN2Protocol.CheckSumSelf ^= nByteData;
				cvGEN2Protocol.StepAnalysisFlag++;

				Uint16To2Byte.Data = 0x0000;

				Uint16To2Byte.byte[1] = nByteData;
				break;
			case DefGEN2PROTOCOL_STEP3_GET_COMMAND1:				
				cvGEN2Protocol.CheckSumSelf ^= nByteData;

				Uint16To2Byte.byte[0] = nByteData;

				cvGEN2Protocol.Command = Uint16To2Byte.Data;
	
				DBG("DefGEN2PROTOCOL_STEP3_GET_COMMAND1, cmd: %04x\n", cvGEN2Protocol.Command);

				cvGEN2Protocol.DataCount = 0;
				cvGEN2Image.ImageCount   = 0;
				cvGEN2Image.ImageLength  = 0;
				if ((cvGEN2Protocol.Command == 0x0281) && (cvGEN2Protocol.Length == 9615)) {
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE1;
				}
				else if ((cvGEN2Protocol.Command == 0x0282) && (cvGEN2Protocol.Length == 9633)) { 
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE1;
				}
				else if ((cvGEN2Protocol.Command == 0x028A) && (cvGEN2Protocol.Length == 10577)) {
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE1;
				}
				else if ((cvGEN2Protocol.Command == 0x028B) && (cvGEN2Protocol.Length == 10597)) {
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE1;
				}
				else if ((cvGEN2Protocol.Command == 0xFFA1) && (cvGEN2Protocol.Length == 1002)) {
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE3;
					cvGEN2Image.PRODUCTINFORCount   = 0;
				}
				else if ((cvGEN2Protocol.Command == 0x0001) && (cvGEN2Protocol.Length == 4)) { //// Test Protocol
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE4;
				}
				else if ((cvGEN2Protocol.Command == 0x1B91) && (cvGEN2Protocol.Length == 4)) { //// SHUTTER Status
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE4;
				}
				else if (((cvGEN2Protocol.Command == 0xFEA2) || (cvGEN2Protocol.Command == 0xFEB2)) && (cvGEN2Protocol.Length == 9774)) {
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE5;
				}
				else if ((cvGEN2Protocol.Command == 0xFEC2) && (cvGEN2Protocol.Length == 15860)) {
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE5;
				}
				else if ((cvGEN2Protocol.Command == 0xFED5) && (cvGEN2Protocol.Length == 290)) {
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE5;
				}
				else if ((cvGEN2Protocol.Command == 0xFEE2) || (cvGEN2Protocol.Command == 0xFEEA)) {
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE5;
				}
				else if ((cvGEN2Protocol.Command == 0xFD24) && (cvGEN2Protocol.Length == 22)) {
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE5;
				}
				else if ((cvGEN2Protocol.Command == 0xFD30) && (cvGEN2Protocol.Length == 4)) {
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE5;
				}
				else if ((cvGEN2Protocol.Command == 0xFD39) && (cvGEN2Protocol.Length == 26)) {
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE5;
				}
				else {
					cvGEN2Protocol.StepAnalysisFlag  = DefGEN2PROTOCOL_STEP1_CHECK_STX;
					cvGEN2Protocol.CommandStatusFlag = DefGEN2PROTOCOL_COMMAND_GETTING_DATA;
					cvGEN2Protocol.DataCount         = 0;
				}
				break;

			case DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE1:
				//DBG("DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE1\n");
				cvGEN2Protocol.CheckSumSelf ^= nByteData;

				if (cvGEN2Protocol.Length <= 9630) {
					switch (cvGEN2Protocol.DataCount) {
						case  0x00: cvGEN2Image.FrameRate = nByteData;                                              break;
						case  0x01: Uint16To2Byte.byte[1] = nByteData;                                              break;
						case  0x02: Uint16To2Byte.byte[0] = nByteData; cvGEN2Image.XSize      = Uint16To2Byte.Data; break;
						case  0x03: Uint16To2Byte.byte[1] = nByteData;                                              break;
						case  0x04: Uint16To2Byte.byte[0] = nByteData; cvGEN2Image.YSize      = Uint16To2Byte.Data; break;
						case  0x05: Uint16To2Byte.byte[1] = nByteData;                                              break;
						case  0x06: Uint16To2Byte.byte[0] = nByteData; cvGEN2Image.VCM        = Uint16To2Byte.Data; break;

						case  0x07: Uint16To2Byte.byte[1] = nByteData; break;
						case  0x08: Uint16To2Byte.byte[0] = nByteData; 
							cvGEN2Image.TEMPSENSOR      = Uint16To2Byte.Data; 
							cvGEN2Image.TEMPSENSORFloat = 10000.0f; //// (Old Type - Store as 10000.0f ) ���� �������� ������ ������ ����
							break;

						case  0x09: Uint16To2Byte.byte[1] = nByteData; break;
						case  0x0A: Uint16To2Byte.byte[0] = nByteData; 
							cvGEN2Image.TEMPMCU      = Uint16To2Byte.Data; 
							cvGEN2Image.TEMPMCUFloat = (float)cvGEN2Image.TEMPMCU; 
							cvGEN2Image.TEMPMCUFloat /= 100.0f; 
							break;

						case  0x0B: Uint16To2Byte.byte[1] = nByteData; break;
						case  0x0C: Uint16To2Byte.byte[0] = nByteData; 
							cvGEN2Image.TEMPBOARD      = Uint16To2Byte.Data;
							cvGEN2Image.TEMPBOARDFloat = (float)cvGEN2Image.TEMPBOARD; 
							cvGEN2Image.TEMPBOARDFloat /= 100.0f;
							break;
					}

					cvGEN2Protocol.Data[cvGEN2Protocol.DataCount] = nByteData; cvGEN2Protocol.DataCount++;										
					if (cvGEN2Protocol.DataCount >= (cvGEN2Protocol.Length - 2)) {
						cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP5_CHECK_ETX;
					}
					if (cvGEN2Protocol.DataCount >= 0x0D) {
						cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE2;
						cvGEN2Image.ImageCount  = 0;
						cvGEN2Image.ImageLength = 0;
						cvGEN2Image.ImageMax    = 0;
						cvGEN2Image.ImageMin    = 4096;
					}
				}
				else {
					switch (cvGEN2Protocol.DataCount) {
						case  0x00: cvGEN2Image.FrameRate = nByteData;   cvGEN2Image.ImgPreData.FrameRate = cvGEN2Image.FrameRate; break;
						case  0x01: Uint16To2Byte.byte[1] = nByteData;                                         break;
						case  0x02: Uint16To2Byte.byte[0] = nByteData; cvGEN2Image.ImgPreData.img_x = cvGEN2Image.XSize = Uint16To2Byte.Data; break;
						case  0x03: Uint16To2Byte.byte[1] = nByteData;                                         break;
						case  0x04: Uint16To2Byte.byte[0] = nByteData; cvGEN2Image.ImgPreData.img_y = cvGEN2Image.YSize = Uint16To2Byte.Data; break;
						case  0x05: Uint16To2Byte.byte[1] = nByteData;                                         break;
						case  0x06: Uint16To2Byte.byte[0] = nByteData; cvGEN2Image.ImgPreData.VCM = cvGEN2Image.VCM   = Uint16To2Byte.Data;   break;

						case  0x07: FloatTo4Byte.byte[3] = nByteData; break;
						case  0x08: FloatTo4Byte.byte[2] = nByteData; break;
						case  0x09: FloatTo4Byte.byte[1] = nByteData; break;
						case  0x0A: FloatTo4Byte.byte[0] = nByteData;
							cvGEN2Image.TEMPSENSORFloat = FloatTo4Byte.Value;
							cvGEN2Image.ImgPreData.sensor_temp = cvGEN2Image.TEMPSENSORFloat;
							cvGEN2Image.TEMPSENSOR      = (short)(cvGEN2Image.TEMPSENSORFloat);
							DBG("TEMPSENSOR temp : %.1f\n", 1.0 * cvGEN2Image.TEMPSENSOR/100);
							break;

						case  0x0B: Uint16To2Byte.byte[1] = nByteData; break;
						case  0x0C: Uint16To2Byte.byte[0] = nByteData; 
							cvGEN2Image.ImgPreData.mcu_temp = Uint16To2Byte.Data;
							cvGEN2Image.TEMPMCU = Uint16To2Byte.Data;
							cvGEN2Image.TEMPMCUFloat = (float)cvGEN2Image.TEMPMCU;
							cvGEN2Image.TEMPMCUFloat /= 100.0f;
							DBG("mcu temp : %.1f\n", cvGEN2Image.TEMPMCUFloat);
							break;

						case  0x0D: Uint16To2Byte.byte[1] = nByteData; break;
						case  0x0E: Uint16To2Byte.byte[0] = nByteData; 
							cvGEN2Image.ImgPreData.board_temp = Uint16To2Byte.Data;
							cvGEN2Image.TEMPBOARD = Uint16To2Byte.Data;
							cvGEN2Image.TEMPBOARDFloat = (float)cvGEN2Image.TEMPBOARD;
							cvGEN2Image.TEMPBOARDFloat /= 100.0f;
							DBG("start data recv end\n");
							break;
					}

					cvGEN2Protocol.Data[cvGEN2Protocol.DataCount] = nByteData; cvGEN2Protocol.DataCount++;

					if (cvGEN2Protocol.DataCount >= (cvGEN2Protocol.Length - 2)) {
						cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP5_CHECK_ETX;
					}
					if (cvGEN2Protocol.DataCount >= 0x0F) {
						cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE2;
						cvGEN2Image.ImageCount  = 0;
						cvGEN2Image.ImageLength = 0;
						cvGEN2Image.ImageMax    = 0;
						cvGEN2Image.ImageMin    = 4096;
					}
				}
				break;
			case DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE2:
				//DBG("DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE2\n");
				cvGEN2Protocol.CheckSumSelf ^= nByteData;
				cvGEN2Protocol.Data[cvGEN2Protocol.DataCount] = nByteData;


				if ((cvGEN2Image.ImageCount % 2) == 0) {
					Uint16To2Byte.byte[1] = nByteData;
					///cvGEN2Image.ImageCount = 1;
				}
				else {
					Uint16To2Byte.byte[0] = nByteData;

					////cvGEN2Image.Image[((cvGEN2Protocol.DataCount-15)/2)] = Uint16To2Byte.Data;
					cvGEN2Image.Image[(cvGEN2Image.ImageCount/2)] = Uint16To2Byte.Data;

					if (cvGEN2Image.ImageCount < 9600)
					{
						nPosXXX = cvGEN2Image.ImageLength % 80;
						nPosYYY = cvGEN2Image.ImageLength / 80;

						cvGEN2Image.ImageLength++;

						if ((nPosXXX >= 2) && (nPosXXX <= 77) && (nPosYYY >= 2) && (nPosYYY <= 57)) {
							if (cvGEN2Protocol.Length < 10000) {
								if (cvGEN2Image.ImageLength < 4800) {
									if (cvGEN2Image.ImageMax < Uint16To2Byte.Data) {
										cvGEN2Image.ImageMax = Uint16To2Byte.Data;
										cvGEN2Image.ImageMaxPoint = cvGEN2Image.ImageLength;
										cvGEN2Image.ImageMaxPointX = nPosXXX;
										cvGEN2Image.ImageMaxPointY = nPosYYY;
									}
									if (cvGEN2Image.ImageMin > Uint16To2Byte.Data) {
										cvGEN2Image.ImageMin = Uint16To2Byte.Data;
										cvGEN2Image.ImageMinPoint = cvGEN2Image.ImageLength;
										cvGEN2Image.ImageMinPointX = nPosXXX;
										cvGEN2Image.ImageMinPointY = nPosYYY;
									}
								}
							}
							else {
								if (cvGEN2Image.ImageMax < Uint16To2Byte.Data) {
									cvGEN2Image.ImageMax = Uint16To2Byte.Data;
									cvGEN2Image.ImageMaxPoint = cvGEN2Image.ImageLength;
									cvGEN2Image.ImageMaxPointX = nPosXXX;
									cvGEN2Image.ImageMaxPointY = nPosYYY;
								}
								if (cvGEN2Image.ImageMin > Uint16To2Byte.Data) {
									cvGEN2Image.ImageMin = Uint16To2Byte.Data;
									cvGEN2Image.ImageMinPoint = cvGEN2Image.ImageLength;
									cvGEN2Image.ImageMinPointX = nPosXXX;
									cvGEN2Image.ImageMinPointY = nPosYYY;
								}
							}
						}
					}
					else
					{
						switch (cvGEN2Image.ImageCount) {
							case 9601 : 
								cvGEN2Image.ImageExtra.Status = Uint16To2Byte.byte[1];
								cvGEN2Image.ImageExtra.FOV    = Uint16To2Byte.byte[0];
								break;
							case 9603:
								cvGEN2Image.ImageExtra.FNumber = Uint16To2Byte.byte[1];
								cvGEN2Image.ImageExtra.Type    = Uint16To2Byte.byte[0];
								break;
							case 9605: 
								cvGEN2Image.ImageExtra.GainValue   = Uint16To2Byte.byte[1];
								cvGEN2Image.ImageExtra.OffsetValue = Uint16To2Byte.byte[0];
								break;
							case 9607: cvGEN2Image.ImageExtra.TData1  = Uint16To2Byte.Data; break;
							case 9609: cvGEN2Image.ImageExtra.TData2  = Uint16To2Byte.Data; break;
							case 9611: cvGEN2Image.ImageExtra.TData3  = Uint16To2Byte.Data; break;
							case 9613: cvGEN2Image.ImageExtra.Extra31 = Uint16To2Byte.Data; break;
							case 9615: 
								{
									DBG("END ImageExtra\n");
									cvGEN2Image.ImageExtra.Extra32 = Uint16To2Byte.Data; 
								}
								break;
						}
					}
				}

				cvGEN2Image.ImageCount++;
				cvGEN2Protocol.DataCount++;
				if (cvGEN2Protocol.DataCount >= (cvGEN2Protocol.Length - 2)) {
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP5_CHECK_ETX;
				}
				break;

			case DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE3:
				DBG("DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE3\n");
				cvGEN2Protocol.CheckSumSelf ^= nByteData;

				cvGEN2Protocol.Data[cvGEN2Protocol.DataCount] = nByteData; cvGEN2Protocol.DataCount++;

				cvGEN2Image.PRODUCTINFOR[cvGEN2Image.PRODUCTINFORCount] = nByteData;
				if ((cvGEN2Image.PRODUCTINFORCount >= 38) && (cvGEN2Image.PRODUCTINFORCount <= 67))
				{
					if ((cvGEN2Image.PRODUCTINFORCount >= 38) && (cvGEN2Image.PRODUCTINFORCount <= 57))
					{
						cvGEN2Image.INLINENumber[(cvGEN2Image.PRODUCTINFORCount - 38)] = nByteData;
					}
					else if ((cvGEN2Image.PRODUCTINFORCount >= 58) && (cvGEN2Image.PRODUCTINFORCount <= 62))
					{
						cvGEN2Image.PRODUCTINFORHWVER[(cvGEN2Image.PRODUCTINFORCount - 58)] = nByteData;
					}
					else if ((cvGEN2Image.PRODUCTINFORCount >= 63) && (cvGEN2Image.PRODUCTINFORCount <= 67))
					{
						cvGEN2Image.PRODUCTINFORSWVER[(cvGEN2Image.PRODUCTINFORCount - 63)] = nByteData;
					}
				}
				else if ((cvGEN2Image.PRODUCTINFORCount >= 116) && (cvGEN2Image.PRODUCTINFORCount <= 125))
				{
					cvGEN2Image.PRODUCTINFORSWDATE[(cvGEN2Image.PRODUCTINFORCount - 116)] = nByteData;
				}

				if (cvGEN2Image.PRODUCTINFORCount < 1002) { cvGEN2Image.PRODUCTINFORCount++; }

				if (cvGEN2Protocol.DataCount >= (cvGEN2Protocol.Length - 2)) {
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP5_CHECK_ETX;
				}
				break;

			case DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE4:
				DBG("DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE4\n");
				cvGEN2Protocol.CheckSumSelf ^= nByteData;

				cvGEN2Protocol.Data[cvGEN2Protocol.DataCount] = nByteData; cvGEN2Protocol.DataCount++;

				if (cvGEN2Protocol.DataCount >= (cvGEN2Protocol.Length - 2)) {
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP5_CHECK_ETX;
				}
				break;

			case DefGEN2PROTOCOL_STEP5_CHECK_ETX:
				DBG("get STEP5_CHECK_ETX\n");
				if (nByteData == DefGEN2PROTOCOL_CODE_ETX) {
					DBG("--->>>>get end byte: %02x\n", nByteData);
					cvGEN2Protocol.StepAnalysisFlag++;
				}
				else {
					cvGEN2Protocol.StepAnalysisFlag = DefGEN2PROTOCOL_STEP1_CHECK_STX;
					cvGEN2Protocol.CommandStatusFlag = DefGEN2PROTOCOL_COMMAND_GETTING_DATA;
					cvGEN2Protocol.DataCount = 0;
					cvGEN2Image.ImageCount   = 0;
				}
				break;

			case DefGEN2PROTOCOL_STEP6_CHECK_CHECKSUM:
				DBG("1-DefGEN2PROTOCOL_STEP6_CHECK_CHECKSUM\n");

				if (cvGEN2Protocol.CheckSumSelf == nByteData) {
					DBG("OK-full frame, DefGEN2PROTOCOL_STEP6_CHECK_CHECKSUM, fps:%d, x:%d, y:%d\n", cvGEN2Image.FrameRate, cvGEN2Image.XSize, cvGEN2Image.YSize);

					////////////////
					cvGEN2Protocol.ImgPreData = cvGEN2Image.ImgPreData;
					cvGEN2Protocol.ImageExtra = cvGEN2Image.ImageExtra;
					////////////////

					cvGEN2Protocol.fps = cvGEN2Image.FrameRate;
					if (cvGEN2Protocol.Command == 0x0001) {
						cvGEN2Protocol.FlagProtocolTest = Def_TRUE;
					}
					else if (cvGEN2Protocol.Command == 0x0281) {
						//// Old Type - Do not Use
						cvGEN2Protocol.FlagGetImageData = Def_FALSE;
						cvGEN2Image.ImageReceivedFalg   = 0x0000;
					}
					else if (cvGEN2Protocol.Command == 0x0282) {
						//// Normal Mode
						DBG("Normal Mode\n");
						cvGEN2Protocol.FlagGetImageData = Def_TRUE;
						cvGEN2Image.ImageReceivedFalg   = 0x0282;

					}
					else if (cvGEN2Protocol.Command == 0x028A) {
						//// Calibration Mode	
						DBG("Calibration Mode\n");					
						cvGEN2Protocol.FlagGetImageData = Def_TRUE;
						cvGEN2Image.ImageReceivedFalg   = 0x028A;
					}
					else if (cvGEN2Protocol.Command == 0x028B) {
						//// Inline Type - Do not Use
						cvGEN2Protocol.FlagGetImageData = Def_FALSE;
						cvGEN2Image.ImageReceivedFalg   = 0x0000;
					}
					else if (cvGEN2Protocol.Command == 0x1B91) {
						if      (cvGEN2Protocol.Data[1] == 2) { cvGEN2Image.ShutterStatus = Def_SHUTTER_OPEN;  }
						else if (cvGEN2Protocol.Data[1] == 1) { cvGEN2Image.ShutterStatus = Def_SHUTTER_CLOSE; }
					}
					else if (cvGEN2Protocol.Command == 0xFFA1) {
						cvGEN2Image.PRODUCTINFORFlag = Def_TRUE;
					}
				}
				else {
					cvGEN2Protocol.DataCount = 0;
					cvGEN2Image.ImageCount   = 0;
				}

				cvGEN2Protocol.StepAnalysisFlag  = DefGEN2PROTOCOL_STEP1_CHECK_STX;
				cvGEN2Protocol.CommandStatusFlag = DefGEN2PROTOCOL_COMMAND_GETTING_DATA;
				break;

		}

	}
//#define  DefGEN2PROTOCOL_COMMAND_CHECK_STANDBY       0
//#define  DefGEN2PROTOCOL_COMMAND_GETTING_DATA        1
//#define  DefGEN2PROTOCOL_COMMAND_ACTIVE              2

	return 0;
}

unsigned int Tools_ConvertCharsToInt16(char* nChars)
{
	unsigned int  nReturn, nLength;
	unsigned int  nFlagStart, nDigitNumber, nLoopI;


	nLength = 0;
	while ((nLength < 5) && (nChars[nLength] >= '0') && (nChars[nLength] <= '9')) { nLength++; }

	nReturn = 0;
	nFlagStart = 0;
	nDigitNumber = 1000;

	nReturn = 0;
	nFlagStart = 0;
	nDigitNumber = 1;
	for (nLoopI = nLength; nLoopI > 0; nLoopI--) {
		nReturn += (nDigitNumber * (nChars[(nLoopI - 1)] - '0'));

		nDigitNumber *= 10;
	}

	return nReturn;
}

void cvGEN2Protocol_GenerateTempData(unsigned short* nPixelData, float* nTempDst)  //// , unsigned short t1, unsigned short t2, unsigned t3)
{
	if (cvGEN2Protocol.SWVersionType >= 5)
	{
		float nSlope = (float)(cvGEN2Image.ImageExtra.GainValue);
		nSlope = nSlope / (float)(cvGEN2Image.ImageExtra.TData2 - cvGEN2Image.ImageExtra.TData1); 

		float nOffset = (float)(cvGEN2Image.ImageExtra.OffsetValue - 120);
		nOffset = nOffset / 10.0f;
		nOffset = nOffset + (float)cvGEN2Image.ImageExtra.TData3;

		for (int i = 0; i < 4800; i++)
		{
			nTempDst[i] = (float)(nPixelData[i] - cvGEN2Image.ImageExtra.TData1);
			nTempDst[i] = ((nSlope * nTempDst[i]) + nOffset);
			nTempDst[i] = nTempDst[i] / 0.98f;
		}
	}
	else if (cvGEN2Protocol.SWVersionType == 4)
	{
	}
}

float cvGEN2Protocol_ConvertTempData(unsigned short nPixelData)  //// , unsigned short t1, unsigned short t2, unsigned t3)
{
	float nRetrunFloat;

	nRetrunFloat = 0.0f;

	if (cvGEN2Protocol.SWVersionType >= 5)
	{
		float nSlope = (float)(cvGEN2Image.ImageExtra.GainValue);
		nSlope = nSlope / (float)(cvGEN2Image.ImageExtra.TData2 - cvGEN2Image.ImageExtra.TData1);

		float nOffset = (float)(cvGEN2Image.ImageExtra.OffsetValue - 120);
		nOffset = nOffset / 10.0f;
		nOffset = nOffset + (float)cvGEN2Image.ImageExtra.TData3;

		nRetrunFloat = (float)(nPixelData - cvGEN2Image.ImageExtra.TData1);
		nRetrunFloat = ((nSlope * nRetrunFloat) + nOffset);
		nRetrunFloat = nRetrunFloat / 0.98f;
	}
	else if (cvGEN2Protocol.SWVersionType == 4)
	{
	}

	return nRetrunFloat;
}
