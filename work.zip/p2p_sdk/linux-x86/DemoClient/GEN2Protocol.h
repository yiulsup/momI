// #pragma once

#ifdef __CV_GEN2_PROTOCOL_H

#define   DefExternCV_GEN2_PROTOCOL


#else

#define   DefExternCV_GEN2_PROTOCOL    extern

#endif /* __CV_GEN2_PROTOCOL_H */

/////////////////////////////////////////////////////////////////////////////
#define IRCAM_CMD_SET_FPS_30	0
#define IRCAM_CMD_SET_FPS_20	1
#define IRCAM_CMD_SET_FPS_15	2
#define IRCAM_CMD_SET_FPS_12	3
#define IRCAM_CMD_SET_FPS_10	4
#define IRCAM_CMD_SET_FPS_6		5
#define IRCAM_CMD_SET_FPS_5		6
#define IRCAM_CMD_SET_FPS_2		7
#define IRCAM_CMD_SET_FPS_1		8
#define IRCAM_CMD_SET_MIRROR	9
#define IRCAM_CMD_SET_START_IMG	10
#define IRCAM_CMD_SET_STOP_IMG	11
#define IRCAM_CMD_SET_UNKNOWN	12
#define IRCAM_CMD_SET_CALIBRAT	13

// GEN2 Protocol Header
#define  Def_FALSE                                    0
#define  Def_TRUE                                     1

#define  Def_SHUTTER_OPEN                             1
#define  Def_SHUTTER_CLOSE                            2

#define  DefGEN2PROTOCOL_DATA_MAX_SIZE               30000

#define  DefGEN2PROTOCOL_CODE_STX                    0x02
#define  DefGEN2PROTOCOL_CODE_ETX                    0x03
#define  DefGEN2PROTOCOL_CODE_ACK                    0x06 ////  6
#define  DefGEN2PROTOCOL_CODE_NAK                    0x15 //// 21

#define  DefGEN2PROTOCOL_STEP1_CHECK_STX             0
#define  DefGEN2PROTOCOL_STEP2_GET_LENGTH0           1
#define  DefGEN2PROTOCOL_STEP2_GET_LENGTH1           2
#define  DefGEN2PROTOCOL_STEP3_GET_COMMAND0          3
#define  DefGEN2PROTOCOL_STEP3_GET_COMMAND1          4
#define  DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE1        5
#define  DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE2        6
#define  DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE3        7
#define  DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE4        8
#define  DefGEN2PROTOCOL_STEP4_GET_DATA_TYPE5        9
#define  DefGEN2PROTOCOL_STEP5_CHECK_ETX             20
#define  DefGEN2PROTOCOL_STEP6_CHECK_CHECKSUM        21

#define  DefGEN2PROTOCOL_COMMAND_CHECK_STANDBY       0
#define  DefGEN2PROTOCOL_COMMAND_GETTING_DATA        1
#define  DefGEN2PROTOCOL_COMMAND_ACTIVE              2

union DefFloatTo4Byte {
	float          Value;
	unsigned char  byte[4];
};
DefExternCV_GEN2_PROTOCOL DefFloatTo4Byte FloatTo4Byte;

union DefUint16To2Byte {
	unsigned short Data;
	unsigned char  byte[2];
};
DefExternCV_GEN2_PROTOCOL DefUint16To2Byte Uint16To2Byte;

typedef struct _PreData_{
	unsigned char  FrameRate;
	short 		   img_x;
	short          img_y;
	short          VCM;
	float		   sensor_temp;
	short		   mcu_temp;
	short		   board_temp;
}PreData_t;

typedef struct PreTailTEMPERATUREINFOR {
	unsigned char      Status;

	unsigned char      FOV;

	unsigned char      FNumber;

	unsigned char      Type;

	unsigned char      GainValue;
	unsigned char      OffsetValue;

	unsigned short     TData1;
	unsigned short     TData2;
	unsigned short     TData3;

	unsigned short     Extra31;
	unsigned short     Extra32;
} cvDefTailTEMPERATUREINFOR;

typedef struct PreGEN2PROTOCOL {
	unsigned char      ClassStartFlag;

	unsigned char      ClassErrorFlag;

	unsigned char      SWVersionType;

	unsigned char      CheckSumSelf;
	unsigned char      CheckSumFromGEN2;

	unsigned char      StepAnalysisFlag;
	unsigned char      CommandStatusFlag;

	unsigned short     Length;

	unsigned short     Command;

	unsigned char      Data[DefGEN2PROTOCOL_DATA_MAX_SIZE];
	unsigned short     DataCount;
	
	unsigned char      FlagProtocolTest;
	unsigned char      FlagPRODUCTINFOR;
	unsigned char      FlagGetImageData;
	unsigned char 	   fps;

	PreData_t				     ImgPreData;
	cvDefTailTEMPERATUREINFOR    ImageExtra;	
} cvDefGEN2Procotol;
DefExternCV_GEN2_PROTOCOL cvDefGEN2Procotol cvGEN2Protocol;


typedef struct PreGEN2ImageINFORMATION {
	//unsigned char            FlagValid;

	//unsigned char            FlagCheckIRCameraModule;

	//unsigned char            FlagReadRegister;
	//unsigned char            ReadRegisterData[30];

	//unsigned char            FlagTestProtocol;
	//unsigned char            TestProtocolEchoData[5];
	unsigned char            FrameRate;
	unsigned short           XSize;
	unsigned short           YSize;

	float                    VCM_F;
	float                    TEMP_F;

	unsigned short           VCM;
	float                    VCMFloat;

	short                    TEMPSENSOR;
	float                    TEMPSENSORFloat;

	short                    TEMPMCU;
	float                    TEMPMCUFloat;
	short                    TEMPBOARD;
	float                    TEMPBOARDFloat;

	unsigned short           ImageReceivedFalg;

	short                    Image[5000];
	unsigned short           ImageLength;
	unsigned short           ImageCount;

	PreData_t				     ImgPreData;
	cvDefTailTEMPERATUREINFOR    ImageExtra;

	unsigned short           ImageMax;
	unsigned short           ImageMin;
	unsigned short           ImageSel;

	unsigned short           ImageMaxPoint;
	unsigned short           ImageMaxPointX;
	unsigned short           ImageMaxPointY;
	unsigned short           ImageMinPoint;
	unsigned short           ImageMinPointX;
	unsigned short           ImageMinPointY;


	unsigned char            PRODUCTINFORFlag;

	unsigned char            PRODUCTINFOR[1024];
	unsigned short           PRODUCTINFORCount;

	unsigned char            PRODUCTINFORHWVER[6];
	unsigned char            PRODUCTINFORSWVER[6];
	unsigned char            PRODUCTINFORSWDATE[11];

	unsigned char            INLINENumber[21];

	unsigned char            OperationMode;
	unsigned char            ShutterStatus;	
} DefGEN2ImageInformation;
DefExternCV_GEN2_PROTOCOL DefGEN2ImageInformation cvGEN2Image;

DefExternCV_GEN2_PROTOCOL void cvGEN2Protocol_Initial(void);
DefExternCV_GEN2_PROTOCOL char cvGEN2Protocol_Analysis(unsigned char* nReceivedData, unsigned short nReceivedLength);

DefExternCV_GEN2_PROTOCOL unsigned int Tools_ConvertCharsToInt16(char* nChars);
DefExternCV_GEN2_PROTOCOL void cvGEN2Protocol_GenerateTempData(unsigned short* arr, float* dst);  //// , unsigned short t1, unsigned short t2, unsigned t3);
DefExternCV_GEN2_PROTOCOL float cvGEN2Protocol_ConvertTempData(unsigned short nPixelData);  //// , unsigned short t1, unsigned short t2, unsigned t3)

int cvGEN2Protocol_SendCommand(int cmd);