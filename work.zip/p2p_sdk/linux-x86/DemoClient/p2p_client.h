#ifndef P2P_CAMERA_H
#define P2P_CAMERA_H

// 0: radar, 1: IR raw data, 2:sensor temp, 3: alarm, 4, string
typedef enum _P2P_USER_DATA_TYPE_{
    P2P_USER_DATA_RADAR = 0,
    P2P_USER_DATA_IR,
    P2P_USER_DATA_TEMP,
    P2P_USER_DATA_ALARM,
    P2P_USER_DATA_STRING,
}P2P_USER_DATA_TYPE;

typedef struct _UserData_{
	int data_type;   // 0: radar, 1: IR raw data, 2:sensor temp, 3: alarm, 4, string 
	int sub_type;    // for alarm
	int user_data_len;
	unsigned char user_data[40 * 1000];
}UserData_t;

int p2p_client_initial(char* szDeviceID);
int p2p_client_clean();
int p2p_client_set_local_addr(char* szLocalIP);
int p2p_client_start(char* szServerIP, int nServerPort, char* szRemoteDeviceID, char* szRemoteDevicePassword);
int p2p_client_stop();
int p2p_client_start_live();
int p2p_client_stop_live();
int p2p_client_get_device_info();
int p2p_client_send_json(char* szJsonData);


int p2p_client_start_userChannel(void);
int p2p_client_stop_userChannel(void);
int p2p_client_test_userChannel(void);

#endif

