#include "p2p_camera.h"

int main()
{
	p2p_camera_start("00030D49", "00030D49");
	p2p_camera_set_local_addr("192.168.0.100");
	p2p_camera_set_server_addr("120.79.169.159", 6000);
	while(1)
	{
		usleep(10 * 1000 * 1000);
	}
	p2p_camera_stop();
	return 0;
}