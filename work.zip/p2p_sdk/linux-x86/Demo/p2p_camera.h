#ifndef P2P_CAMERA_H
#define P2P_CAMERA_H

int p2p_camera_start(char* szDeviceID, char* szPrivateKey);
int p2p_camera_set_local_addr(char* szLocalIP);
int p2p_camera_set_server_addr(char* szServerIP, int nServerPort);
int p2p_camera_send_audio(unsigned char *data, int len);
int p2p_camera_send_video(unsigned char *data, int len, int nVideoFrameType, int width, int height);
int p2p_camera_stop();

#endif

