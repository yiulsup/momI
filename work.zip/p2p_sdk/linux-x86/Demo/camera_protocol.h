#ifndef CAMERA_USER_PROTOCOL_H
#define CAMERA_USER_PROTOCOL_H

#define UCMDQUERYCAMERAINFOREQ 2000
#define UCMDQUERYCAMERAINFORSP 2001
#define UCMDQUERYCAMERARECORDREQ 2002
#define UCMDQUERYCAMERARECORDRSP 2003
#define UCMDSETWIFIREQ 2004
#define UCMDSETWIFIRSP 2005
#define UCMDQUERYENCODERREQ 2006
#define UCMDQUERYENCODERRSP 2007
#define UCMDSETENCODERREQ 2008
#define UCMDSETENCODERRSP 2009
#define UCMDQUERYCAMERANAMEREQ 2010
#define UCMDQUERYCAMERANAMERSP 2011
#define UCMDSETCAMERANAMEREQ 2012
#define UCMDSETCAMERANAMERSP 2013
#define UCMDSETPASSWORDREQ 2014
#define UCMDSETPASSWORDRSP 2015
#define UCMDQUERYTIMEZONEREQ 2016
#define UCMDQUERYTIMEZONERSP 2017
#define UCMDSETTIMEZONEREQ 2018
#define UCMDSETTIMEZONERSP 2019
#define UCMDSETTIMEREQ 2020
#define UCMDSETTIMERSP 2021
#define UCMDFORMATSDCARDREQ 2022
#define UCMDFORMATSDCARDRSP 2023
#define UCMDQUERYRECORDMODEREQ 2024
#define UCMDQUERYRECORDMODERSP 2025
#define UCMDSETRECORDMODEREQ 2026
#define UCMDSETRECORDMODERSP 2027
#define UCMDQUERYMOTIONINFOREQ 2028
#define UCMDQUERYMOTIONINFORSP 2029
#define UCMDSETMOTIONINFOREQ 2030
#define UCMDSETMOTIONINFORSP 2031
#define UCMDQUERYBDINFOREQ 2032
#define UCMDQUERYBDINFORSP 2033
#define UCMDSETBDINFOREQ 2034
#define UCMDSETBDINFORSP 2035
#define UCMDSTARTPLAYBACKREQ 2036
#define UCMDSTARTPLAYBACKRSP 2037
#define UCMDPAUSEPLAYBACKREQ 2038
#define UCMDPAUSEPLAYBACKRSP 2039
#define UCMDSTOPPLAYBACKREQ 2040
#define UCMDSTOPPLAYBACKRSP 2041
#define UCMDQUERYWIFIREQ 2042
#define UCMDQUERYWIFIRSP 2043
#define UCMDSETDEVICEIDREQ 2044
#define UCMDSETDEVICEIDRSP 2045 
#define UCMDTRIGGERRECORDREQ 2046
#define UCMDTRIGGERRECORDRSP 2047
#define UCMDPTZCONTROLREQ 2048
#define UCMDPTZCONTROLRSP 2049

#define UCMDUPGRADEASKREQ 2060
#define UCMDUPGRADEASKRSP 2061
#define UCMDDOUPGRADEREQ 2062
#define UCMDDOUPGRADERSP 2063
#define UCMDUPGRADEPROGRESSREQ 2064
#define UCMDUPGRADEPROGRESSRSP 2065

#define UCMDSETLEDCOLOURREQ 2066
#define UCMDSETLEDCOLOURRSP 2067
#define UCMDQUERYLEDCOLOURREQ 2068
#define UCMDQUERYLEDCOLOURRSP 2069

#define UCMDUPGRADECHECKREQ 2070
#define UCMDUPGRADECHECKRSP 2071

#define UCMDQUERYRCOORDINATEREQ 2072
#define UCMDQUERYRCOORDINATERRSP 2073
#define UCMDQUERYRMIRRORANDFLIPREQ 2074
#define UCMDQUERYRMIRRORANDFLIPRSP 2075
#define UCMDSETMIRRORANDFLIPREQ 2076
#define UCMDSETMIRRORANDFLIPRSP 2077

#define UCMDSETCOORDINATEREQ 2078
#define UCMDSETCOORDINATERRSP 2079

#define UCMDSETBABYVOICEINFOREQ 2080
#define UCMDSETBABYVOICEINFORSP 2081
#define UCMDQUERYRBABYVOICEINFOREQ 2082
#define UCMDQUERYRBABYVOICEINFORSP 2083

#define UCMDSETHOMEMODEREQ 2084
#define UCMDSETHOMEMODERSP 2085
#define UCMDQUERYHOMEMODEREQ 2086
#define UCMDQUERYHOMEMODERSP 2087

#define UCMDCAMERAPROBEREQ 10001
#define UCMDCAMERAPROBERSP 10002
#define UCMDQUERYBINDREQ 10003
#define UCMDQUERYBINDRSP 10004
#define UCMDSETBINDREQ 10005
#define UCMDSETBINDRSP 10006
#define UCMDDISABLECLOURSTORAGEREQ 10007
#define UCMDDISABLECLOURSTORAGERSP 10008
#define UCMDSTARTRTMPPUSHREQ 10009
#define UCMDSTARTRTMPPUSHRSP 10010
#define UCMDSTOPRTMPPUSHREQ 10011
#define UCMDSTOPRTMPPUSHRSP 10012
#define UCMDGETRTMPINFOREQ 10013
#define UCMDGETRTMPINFORSP 10014

#define UCMDRELEASEFIRSTLOCKREQ 20000
#define UCMDRELEASEFIRSTLOCKRSP 20001

#define CAPFLAG_MOTIONDETECTION 1
#define CAPFLAG_BODYDETECTION 2
#define CAPFLAG_WIFI 3

#define DEVICEID_ENCRYPTION_SIZE 24
#define DEVICEID_SIZE 24

typedef struct sturct_start_rtmp_req
{
	unsigned short channel;
	char url[256];
}STARTRTMPREQ;

typedef struct sturct_start_rtmp_rsp
{
	unsigned short channel;
	unsigned short state;
}STARTRTMPRSP;

typedef struct sturct_stop_rtmp_req
{
	unsigned short channel;
}STOPRTMPREQ;

typedef struct sturct_stop_rtmp_rsp
{
	unsigned short channel;
	unsigned short state;
}STOPRTMPRSP;

typedef struct sturct_get_rtmp_info_req
{
	unsigned short channel;
}GETRTMPINFOREQ;

typedef struct sturct_get_rtmp_info_rsp
{
	unsigned short channel;
	unsigned short state;
	char url[256];
}GETRTMPINFORSP;

typedef struct struct_release_first_lock_req
{
	unsigned short channel;
}RELEASEFIRSTLOCKREQ;

typedef struct struct_release_first_lock_rsp
{
	unsigned short channel;
	unsigned short state;
	int m_nBlkID;
}RELEASEFIRSTLOCKRSP;

typedef struct struct_query_bind_req
{
	unsigned short channel;
}QUERYBINDREQ, QUERYCOORDINATEREQ;

typedef struct struct_query_bind_rsp
{
	int channel;
	int type;
	char ip[32];
	int port1;
	int port2;
	char szUserName[32];
	char szPassword[32];
}QUERYBINDRSP;

typedef struct struct_set_bind_req
{
	int channel;
	int type;
	char ip[32];
	int port1;
	int port2;
	char szUserName[32];
	char szPassword[32];
}SETBINDREQ;

typedef struct struct_mirrorandflip
{
	unsigned short channel;	
	unsigned char mirror;
	unsigned char flip;
}SETMIRRORANDFLIP,QUERYRMIRRORANDFLIP;

typedef struct struct_camera_probe_rsp
{
	char uri[256];
}CAMERAPROBERSP;

typedef struct struct_ptzcontrol_req
{
	unsigned short channel;
	unsigned short cmd;// 1-->left,2-->right,3-->up,4-->down,5-->goto
	char param[8];
}PTZCONTROLREQ;

typedef struct struct_triggerrecord_rsp
{
	int result;
}TRIGGERRECORDRSP;

typedef struct struct_triggerrecord_req
{
	unsigned short channel;
	char status;//0,start; 1,stop;
}TRIGGERRECORDREQ;

typedef struct struct_capability_content
{
	unsigned char nSpeakEncodeType;
	unsigned char nSpeakSampleRate;
	char m_function[16];
}CAPABILITYCONTENT;

typedef struct struct_set_device_id_req
{
	char szEncryption[DEVICEID_ENCRYPTION_SIZE];
	char szDeviceID[DEVICEID_SIZE];
}SETDEVICEIDREQ;

typedef struct struct_set_device_id_rsp
{
	int result;
}SETDEVICEIDRSP;

typedef struct struct_camera_info_rsp
{
	char szDeviceType[64];
	char szFirmVersion[64];
	char szManufacture[64];
	int nTotalSpace;
	int nFreeSpace;
	int nBatteryValue;
}USERCAMERAINFORSP;


typedef struct struct_set_wifi_req
{
	unsigned char ssid[32];			//WiFi ssid
	unsigned char password[32];		//if exist, WiFi password
	unsigned char mode;			//refer to ENUM_AP_MODE
	unsigned char enctype;			//refer to ENUM_AP_ENCTYPE
	unsigned char reserved[10];
}SETWIFIREQ;

typedef struct struct_set_wifi_rsp
{
	int result;
}SETWIFIRSP;


typedef struct struct_get_wifi_rsp
{
	unsigned char ssid[32];			//WiFi ssid
}GETWIFIRSP;

typedef struct struct_set_password_req
{
	char szPWOld[32];
	char szPWNew[32];
}SETPASSWORDREQ;

typedef struct struct_time_zone_req
{
	int nGMTDiff;//unit is minute
	char szTimeZoneString[256];
}SETTIMEZONEREQ,GETTIMEZONERSP;

typedef struct struct_set_time_req
{
	unsigned int nTimeHigh;
	unsigned int nTimeLow;
}SETTIMEREQ;


typedef struct struct_set_encoder_rsp
{
	int result;
}SETENCODERRSP,
SETCAMERANAMERSP,
SETPASSWORDRSP,
SETTIMEZONERSP,
SETTIMERSP,
FORMATSDCARDRSP,
DISABLECLOURSTORAGERSP,
SETRECORDMODERSP,
SETMOTIONINFORSP,
SETBDINFORSP,
SETMIRRORANDFLIPRSP,
SETBAYVOICEINFORSP,
SETHOMEMODERSP;

typedef struct struct_camera_req
{
	unsigned short channel;
	unsigned short reserve;
}GETENCODERREQ,
GETCAMERANAMEREQ,
GETRECORDMODEREQ,
GETMOTIONINFOREQ,
GETBDINFOREQ;

typedef struct struct_set_coordinate
{
	unsigned short channel;
	unsigned short type;
	unsigned short x;
	unsigned short y;
	unsigned short radius;
}SETCOORDINATEREQ,QUERYRCOORDINATERRSP;

typedef struct struct_set_record_mode
{
	unsigned short channel;
	char mode;//0,closed; 1,alarm record; 2,continual record
	char reserve;
}SETRECORDMODEREQ,GETRECORDMODERSP;

typedef struct struct_motion_info
{	
	unsigned short channel;
	char sensitivity;//0,closed; 1,20%; 2,40%; 3,60%; 4,80%
	char reserve;
}SETMOTIONINFOREQ,GETMOTIONINFORSP;

typedef struct struct_set_bd_detect
{
	unsigned short channel;
	char sensitivity;//0,closed; 1,20%; 2,40%; 3,60%; 4,80%
	char reserve;
}SETBDINFOREQ,
GETBDINFORSP,
SETBABYVOICEINFOREQ,
GETBABYVOICEINFORSP,
SETHOMEMODEREQ,
GETHOMEMODERSP;

typedef struct struct_get_camera_name_req
{
	unsigned short channel;
	unsigned short reserve;
	char szName[32];
}SETCAMERANAMEREQ,QUERYCAMERANAMERSP;

typedef struct struct_encoder_info
{
	unsigned short channel;
	unsigned short resolution;//0,standard;1,high;2,fluence
	unsigned short frameRate;
	unsigned short reserve;
}SETENCODERREQ,QUERYENCODERRSP;

typedef struct struct_camera_record_req
{
	char szDevice[24];
	int nType;
	int nHighBeginTime;
	int nLowBeginTime;
	int nHighEndTime;
	int nLowEndTime;
}USERCAMERARECORDREQ;

typedef struct struct_file_item
{
	int fileHandle[4];
	int nRelativeData;
	unsigned int nHighBeginTime;
	unsigned int nLowBeginTime;
	unsigned int nHighEndTime;
	unsigned int nLowEndTime;
	unsigned int nFileSize;
}FILEITEM;

typedef struct struct_camera_record_rsp
{
	unsigned short nFileBeginIndex;
	unsigned short nFileCount;
	char szDeviceID[24];
}USERCAMERARECORDRSP;


typedef struct struct_start_playback
{
	unsigned int nSessionID;
	int fileHandle[4];
	unsigned int nHighTime;
	unsigned int nLowTime;	
}USERCAMERAPLAYBACKREQ;

typedef struct struct_stop_playback
{
	unsigned int nSessionID;
}USERCAMERASTOPPLAYBACKREQ, USERCAMERAPAUSEPLAYBACKREQ;

typedef struct struct_playback_rsp
{
	int result;
}USERSTARTPLAYBACKRSP,
USERPAUSEPLAYBACKRSP,
USERSTOPLAYBACKRSP,
SETCOORDINATERRSP,
UPGRADEASKRSP,
UPGRADEPROGRESSRSP;


#endif
