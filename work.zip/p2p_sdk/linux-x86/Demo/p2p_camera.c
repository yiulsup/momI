#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <pthread.h>
#include <unistd.h>
#include <stdarg.h>
#include <sys/time.h>
#include "p2p_camera.h"
#include "P2PTranc.h"
#include "P2PSvrc.h"
#include "P2PSearchc.h"
#include "RingBuffer.h"
#include "camera_protocol.h"

#define AVSESSIONCOUNT 3
#define AVBUFFERSIZE 200
#define SPEAKBUFFERSIZE 40

#define CMDBUFFERSIZE (5 * 1024)
#define PLAYBACKBUFFERSIZE (40 * 1024)
#define LIVEBUFFERSIZE (40 * 1024)

#define MSGINBUFFERSIZE 5 * 1024
	
#define USEGLOBALMEMORY

#ifdef USEGLOBALMEMORY

#define VBUFFERCOUNT 10
#define VBUFFERSIZE (400 * 1024)
char *m_VideoBuffer = 0;
char *m_bVideoUsed = 0;

int ReleaseVideoBuffer(char* data)
{
	int pos = (data - m_VideoBuffer) / VBUFFERSIZE;
	if(pos >= 0 && pos < VBUFFERCOUNT)
	{
		m_bVideoUsed[pos] = 0;
	}
	return 0;
}

char* AllocVideoBuffer(int size)
{
	int i;
	for(i = 0; i < VBUFFERCOUNT; i++)
	{
		if(m_bVideoUsed[i] == 0)
		{
			m_bVideoUsed[i] = 1;
			return m_VideoBuffer + i * VBUFFERSIZE;
		}
	}
	return 0;
}

#define ABUFFERCOUNT 10
#define ABUFFERSIZE (2 * 1024)
char *m_AudioBuffer = 0;
char *m_bAudioUsed = 0;

int ReleaseAudioBuffer(char* data)
{
	int pos = (data - m_AudioBuffer) / ABUFFERSIZE;
	if(pos >= 0 && pos < ABUFFERCOUNT)
	{
		m_bAudioUsed[pos] = 0;
	}
	return 0;
}

char* AllocAudioBuffer(int size)
{
	int i;
	for(i = 0; i < ABUFFERCOUNT; i++)
	{
		if(m_bAudioUsed[i] == 0)
		{
			m_bAudioUsed[i] = 1;
			return m_AudioBuffer + i * ABUFFERSIZE;
		}
	}
	return 0;
}

#define SBUFFERCOUNT 10
#define SBUFFERSIZE (2 * 1024)
static char *m_speakBuffer = 0;
static char *m_bSpeakUsed = 0;

int ReleaseSpeakBuffer(char* data)
{
	int pos = (data - m_speakBuffer) / SBUFFERSIZE;
	if(pos >= 0 && pos < SBUFFERCOUNT)
	{
		m_bSpeakUsed[pos] = 0;
	}
	return 0;
}

char* AllocSpeakBuffer(int size)
{
	int i;
	for(i = 0; i < SBUFFERCOUNT; i++)
	{
		if(m_bSpeakUsed[i] == 0)
		{
			m_bSpeakUsed[i] = 1;
			return m_speakBuffer + i * SBUFFERSIZE;
		}
	}
	return 0;
}

int InitialGlobalMemory()
{
	int i;
    m_VideoBuffer = (char*)malloc(VBUFFERCOUNT * VBUFFERSIZE);
    m_bVideoUsed  = (char*)malloc(VBUFFERCOUNT);
    for(i = 0; i < VBUFFERCOUNT; i++)
    {
        m_bVideoUsed[i] = 0;
    }
    m_speakBuffer = (char*)malloc(SBUFFERCOUNT * SBUFFERSIZE);
    m_bSpeakUsed  = (char*)malloc(SBUFFERCOUNT);
    for(i = 0; i < SBUFFERCOUNT; i++)
    {
        m_bSpeakUsed[i] = 0;
    }
    m_AudioBuffer = (char*)malloc(ABUFFERCOUNT * ABUFFERSIZE);
    m_bAudioUsed  = (char*)malloc(ABUFFERCOUNT);
    for(i = 0; i < ABUFFERCOUNT; i++)
    {
        m_bAudioUsed[i] = 0;
    }

    return 0;
}

int CleanGlobalMemory()
{
    if(m_speakBuffer != 0)
    {
        free(m_speakBuffer);
        m_speakBuffer = 0;
    }
    if(m_bSpeakUsed != 0)
    {
        free(m_bSpeakUsed);
        m_bSpeakUsed = 0;
    }
    if(m_AudioBuffer != 0)
    {
        free(m_AudioBuffer);
        m_AudioBuffer = 0;
    }
    if(m_bAudioUsed != 0)
    {
        free(m_bAudioUsed);
        m_bAudioUsed = 0;
    }
    if(m_VideoBuffer != 0)
    {
        free(m_VideoBuffer);
        m_VideoBuffer = 0;
    }
    if(m_bVideoUsed != 0)
    {
        free(m_bVideoUsed);
        m_bVideoUsed = 0;
    }

    return 0;
}

#endif

typedef struct
{
	char m_szDeviceID[32];
	int m_bStartLive;
	int m_bLiveStarted;
	int m_nResolution;
	int m_nSize;

	pthread_mutex_t m_lockMsg;
	unsigned char m_msgInBuffer[MSGINBUFFERSIZE];
	CRingBuffer m_ringBufferIn;
	char m_buffer[1036];

	unsigned char m_nLiveFrameID;
	char m_headerVideo[64];
	char m_headerAudio[64];
}CP2PCamera;

static CP2PCamera g_p2pCamera = {0};

int WriteMsg(int nClientID, char *buffer, int len)
{
	return P2PSvrClientSend(nClientID, 0, 
			buffer, sizeof(P2PCMDHEADER), buffer + sizeof(P2PCMDHEADER), 
			len - sizeof(P2PCMDHEADER));
}


int HandleSetEncoder(int nClientID,P2PCMDHEADER* header)
{
	char* buffer = (char*)header;
	header->cmdID = UCMDSETENCODERRSP;
	SETENCODERREQ* req = (SETENCODERREQ*)(buffer + sizeof(P2PCMDHEADER));
	g_p2pCamera.m_nResolution = req->resolution;
	printf("HandleSetEncoder FrameRate=%d,Resolution=%d\n", req->frameRate, req->resolution);
	SETENCODERRSP *setEncoderRsp = (SETENCODERRSP*)(buffer + sizeof(P2PCMDHEADER));
	setEncoderRsp->result = 0;
	WriteMsg(nClientID,buffer, sizeof(P2PCMDHEADER) + sizeof(SETENCODERRSP));
	return 0;
}

int HandleGetEncoder(int nClientID,P2PCMDHEADER* header)
{
	char* buffer = (char*)header;
	header->cmdID = UCMDQUERYENCODERRSP;
	QUERYENCODERRSP *getEncoderRsp = (QUERYENCODERRSP*)(buffer + sizeof(P2PCMDHEADER));
	getEncoderRsp->resolution = g_p2pCamera.m_nResolution;//0,vga;1,720P
	getEncoderRsp->frameRate = 30;
	printf("HandleGetEncoder FrameRate=%d,Resolution=%d\n", getEncoderRsp->frameRate, getEncoderRsp->resolution);
	WriteMsg(nClientID,buffer, sizeof(P2PCMDHEADER) + sizeof(QUERYENCODERRSP));
	return 0;
}

int P2POutputLog(char *pMsg)
{
	printf("P2POutputLog[%s]\n", pMsg);
	return 0;
}

int OnMsg(int nClientID, P2PCMDHEADER* header)
{	
	switch(header->cmdID)
	{
	case UCMDSETENCODERREQ:
		{
			HandleSetEncoder(nClientID,header);
		}
		break;
	case UCMDQUERYENCODERREQ:
		{
			HandleGetEncoder(nClientID,header);
		}
		break;
	default:
		break;
	};

	return 0;
}

int PushMsg(void *hSessionID, char* data, int len)
{
	int nClientID;
	P2PCMDHEADER* header = (P2PCMDHEADER*)data;
	if(len < sizeof(P2PCMDHEADER))
	{
		return 0;
	}	
	nClientID = P2PSvrGetClientID(hSessionID);
	pthread_mutex_lock(&g_p2pCamera.m_lockMsg);
	PushPacket2(&g_p2pCamera.m_ringBufferIn, (char*)&nClientID, sizeof(nClientID), data, len);
	pthread_mutex_unlock(&g_p2pCamera.m_lockMsg);
	return 0;
}

int ReadMsg(char* buffer)
{
	int res;
	pthread_mutex_lock(&g_p2pCamera.m_lockMsg);
	res = PopPacket1(&g_p2pCamera.m_ringBufferIn, buffer);
	pthread_mutex_unlock(&g_p2pCamera.m_lockMsg);
	return res;
}

int HandleMsg()
{
	int nClientID;
	P2PCMDHEADER* header;
	int len = ReadMsg(g_p2pCamera.m_buffer);
	if(len <= 0)
	{
		return 0;
	}
	g_p2pCamera.m_buffer[len]='\0';
	nClientID = *(int*)g_p2pCamera.m_buffer;
	header = (P2PCMDHEADER*)(g_p2pCamera.m_buffer + sizeof(int));
	OnMsg(nClientID, header);
	return 1;
}

int HandleStartLive()
{
	if(g_p2pCamera.m_bStartLive == 1 && g_p2pCamera.m_bLiveStarted == 0)
	{
		//可以在这里去请求关键帧
		g_p2pCamera.m_bLiveStarted = 1;
	}

	if(g_p2pCamera.m_bStartLive == 0 && g_p2pCamera.m_bLiveStarted == 1)
	{
		g_p2pCamera.m_bLiveStarted = 0;
	}
	
	return 0;
}

void *thread_msg(void *param)
{
	while(1)
	{
		int nActionCount = HandleMsg();
		nActionCount += HandleStartLive();
		if(nActionCount <= 0)
		{
			usleep(10 * 1000);
		}
	}
}

int OnSvrP2PRelease(HDATA hData, int nUserData, int result)
{
    if(nUserData == 1)
    {
#ifdef USEGLOBALMEMORY
        ReleaseVideoBuffer((char*)hData);
#else
        free(data);
#endif
    }

    if(nUserData == 2)
    {
#ifdef USEGLOBALMEMORY
        ReleaseAudioBuffer((char*)hData);
#else
        free(data);
#endif
    }
	return 0;
}

int OnSvrP2PEvent(int nEventID, char* data, int len)
{
	switch(nEventID)
	{
	case EVENT_NOSERVERADDR:
		{
			int nIndex = *(int*)data;
			switch(nIndex)
			{
			case 0:
				break;
			case 1:
				break;
			case 2:
				break;
			}
		}
		break;
	case EVENT_DISCONNECTED:
		{
			
		}
		break;
	default:
		break;
	}

	return 0;
}

int OnSvrSessionCheck(unsigned int nClientID, int nSessionChannel, int nSessionType)
{

	return 0;
}

int OnSvrClientAccept(unsigned int nClientID)
{


	return 0;
}

int OnSvrClientClose(unsigned int nClientID)
{


	return 0;
}

int OnSvrSessionStart(void *hSession, char* sessionData, int nSessionDataLen)
{
	unsigned int nSessionType = P2PSvrGetSessionType(hSession);
	unsigned int nSessionChannel = P2PSvrGetSessionChannel(hSession);
	switch(nSessionType)
	{
	case SESSIONTYPE_LIVE:
		{
			g_p2pCamera.m_bStartLive = 1;
		}
		break;
	case SESSIONTYPE_PLAYBACK:
		{

		}
		break;
	case SESSIONTYPE_SPEAK:
		{

		}
		break;
	}

	return 0;
}

int OnSvrSessionStop(void* hSession, char* sessionData, int nSessionDataLen)
{
	int nSessionID = *(int*)sessionData;
	switch(nSessionID)
	{
	case SESSIONTYPE_LIVE:
		{
			g_p2pCamera.m_bStartLive = 0;
		}
		break;
	case SESSIONTYPE_PLAYBACK:
		{

		}
		break;
	case SESSIONTYPE_SPEAK:
		{

		}
		break;
	}

	return 0;
}

int OnSvrSessionData(void *hSession, char* data, int len)
{
	unsigned int nSessionType = P2PSvrGetSessionType(hSession);
	switch(nSessionType)
	{
	case SESSIONTYPE_SPEAK:
		{

		}
		break;
	case SESSIONTYPE_CMD:
		{
			PushMsg(hSession, data, len);
		}
		break;
	}
	return 0;
}

int OnSvrJsonData(unsigned int ip, unsigned short port, char* data)
{
	
	return 0;
}

int OnSvrGetPassword(char* szUserName, char* szPassword)
{
	if (strcmp(szUserName, "admin") == 0)
	{
		strcpy(szPassword, "admin");
		return 1;
	}
	return 0;
}

int OnSvrGetCapacity(unsigned int nClientID, CAPABILITYINFO* capInfo)
{
	capInfo->nCapabilityType = 0;
	capInfo->nCapabilityLength = sizeof(CAPABILITYCONTENT);
	CAPABILITYCONTENT* content = (CAPABILITYCONTENT*)(capInfo + 1);
	content->nSpeakEncodeType = 1;
	content->nSpeakSampleRate = 0;
	return 0;
}

int OnSearchData(void* context, char* szIP, unsigned short port, char* data, int len)
{
	
	return 0;
}

int p2p_camera_send_audio(unsigned char * data, int len)
{
	char* dataNew;
#ifdef USEGLOBALMEMORY
    dataNew = (char*)AllocAudioBuffer(len);
#else
    dataNew = (char*)malloc(len);
#endif
    if(dataNew == 0)
    {
        printf("failed to alloc dataNew!\n");
        return 0;
    }
    memcpy(dataNew, data, len);
	
	int res;
	P2PFRAMEHEADER* header = (P2PFRAMEHEADER*)g_p2pCamera.m_headerAudio;
	header->vendor = 0;
	header->frameType = 2;
	header->nTimeStampHigh = 0;
	header->nTimeStampLow = 0;
	P2PAUDIOFRAME* frame = (P2PAUDIOFRAME*)(g_p2pCamera.m_headerAudio + sizeof(P2PFRAMEHEADER));
	frame->nEncodeType = 2;
	frame->audioFrameID = 0;
	frame->nLength = len;
	res = P2PSvrSessionSend(-1, 1, dataNew, 2, g_p2pCamera.m_headerAudio, sizeof(P2PFRAMEHEADER) + sizeof(P2PAUDIOFRAME), 
							(char *)dataNew, len);
			
	if(res <= 0)
	{
#ifdef USEGLOBALMEMORY
		ReleaseAudioBuffer(dataNew);
#else
		free(dataNew);
#endif
		return -1;
	}
	
	return 0;
}

int p2p_camera_send_video(unsigned char *data, 
						int len, 
						int nVideoFrameType,
						int width,
						int height)
{
	char* dataNew;
#ifdef USEGLOBALMEMORY
    dataNew = (char*)AllocVideoBuffer(len);
#else
    dataNew = (char*)malloc(len);
#endif
    if(dataNew == 0)
    {
        printf("failed to alloc dataNew!\n");
        return 0;
    }
    memcpy(dataNew, data, len);
	
	int res;
	P2PVIDEOFRAME* frame;
	P2PFRAMEHEADER* header = (P2PFRAMEHEADER*)g_p2pCamera.m_headerVideo;
	header->vendor = 0;
	header->frameType = 1;
	header->nTimeStampHigh = 0;
	header->nTimeStampLow = 0;
	frame = (P2PVIDEOFRAME*)(g_p2pCamera.m_headerVideo + sizeof(P2PFRAMEHEADER));
	frame->nWidth  = width;
	frame->nHeight = height;
	frame->videoFrameType = nVideoFrameType;
	if(frame->videoFrameType == VIDEOFRAMETYPE_I)
	{
		g_p2pCamera.m_nLiveFrameID = 0;
	}
	else
	{
		g_p2pCamera.m_nLiveFrameID++;
	}

	frame->videoFrameGroupID = 0;
	frame->videoFrameGroupEnd = 1;
	frame->videoFrameID = g_p2pCamera.m_nLiveFrameID;
	assert(len < (AVBUFFERSIZE * 1024));

	printf("P2PSvrSessionSend FrameType=%d-type=%d-%d-%d-%d %d-len=%d\n", frame->videoFrameType, 
							dataNew[0], dataNew[1], dataNew[2], dataNew[3],
							dataNew[4] & 0x1F, len);

	res = P2PSvrSessionSend(-1, 1, (char *)dataNew, 1, g_p2pCamera.m_headerVideo, sizeof(P2PFRAMEHEADER) + sizeof(P2PVIDEOFRAME), 
			(char *)dataNew, len);
	if(res <= 0)
	{
#ifdef USEGLOBALMEMORY
		ReleaseVideoBuffer(dataNew);
#else
		free(dataNew);
#endif
		return -1;
	}

	return 0;
}

void *p2p_memory_alloc(void* context, char* szTag, int nSize)
{
	g_p2pCamera.m_nSize += nSize;
	printf("p2p_memory_alloc %s-%d\n", szTag, nSize);
	return malloc(nSize);
}

int p2p_camera_start(char* szDeviceID, char* szPrivateKey)
{
	SVRMEMORYPARAM svrMemoryParam;
	SVRCLIENTMEMORYPARAM svrClientMemoryParam;
	UDPMEMORYPARAM svrUdpMemoryParam;
	
	InitialGlobalMemory();
		
	P2PInitial(p2p_memory_alloc, 0);

	CP2PSvrCallback p2pCallback;
	p2pCallback.m_svrSessionCheckCB = OnSvrSessionCheck;
	p2pCallback.m_svrClientAcceptCB = OnSvrClientAccept;
	p2pCallback.m_svrClientCloseCB = OnSvrClientClose;
	p2pCallback.m_svrGetPasswordCB = OnSvrGetPassword;
	p2pCallback.m_svrGetCapacityCB = OnSvrGetCapacity;
	p2pCallback.m_svrSessionAcceptCB = OnSvrSessionStart;
	p2pCallback.m_svrSessionCloseCB = OnSvrSessionStop;
	p2pCallback.m_svrSessionDataCB = OnSvrSessionData;
	p2pCallback.m_svrJsonDataCB = OnSvrJsonData;
	p2pCallback.m_svrEventCB = OnSvrP2PEvent;
	p2pCallback.m_svrReleaseDataCB = OnSvrP2PRelease;

	svrMemoryParam.m_nJsonStatusRingBufferSize = CMDBUFFERSIZE;
	svrMemoryParam.m_nCMDRingBufferSize = CMDBUFFERSIZE;
	svrMemoryParam.m_nLiveRingBufferSize = LIVEBUFFERSIZE;
	svrMemoryParam.m_nRecordRingBufferSize = PLAYBACKBUFFERSIZE;
	svrMemoryParam.m_nUserRingBufferSize = LIVEBUFFERSIZE;

	svrClientMemoryParam.nMaxClientCount = 6;
	svrClientMemoryParam.nMaxChannelCount = 1;

	svrClientMemoryParam.nCMDSessionCount = 0;
	svrClientMemoryParam.nCMDSendBufferSize = 100;
	svrClientMemoryParam.nCMDGroupSize = 1;
	svrClientMemoryParam.nCMDReadBufferSize = 100;

	svrClientMemoryParam.nUserDataSessionCount = 1;
	svrClientMemoryParam.nUDSendBufferSize = 1;
	svrClientMemoryParam.nUDGroupSize = 1;
	svrClientMemoryParam.nUDReadBufferSize = 1;

	svrClientMemoryParam.nAVSessionCount = AVSESSIONCOUNT;
	svrClientMemoryParam.nAVSendBufferSize = AVBUFFERSIZE;
	svrClientMemoryParam.nAudioSendBufferSize = 5;

	svrClientMemoryParam.nSpeakSessionCount = 1;
	svrClientMemoryParam.nSpeakGroupSize = 1;
	svrClientMemoryParam.nSpeakReadBufferSize = SPEAKBUFFERSIZE;

	svrUdpMemoryParam.m_nUDPSendBufferSize = 100 * 1024;
	svrUdpMemoryParam.m_nUDPReadBufferSize = 20 * 1024;
	svrUdpMemoryParam.m_nUDPPacketSize = 2 * 1024;

	P2PSvrSetMemory(MEMORYTYPE_SVR, (char*)&svrMemoryParam);
	P2PSvrSetMemory(MEMORYTYPE_SVR_SESSION, (char*)&svrClientMemoryParam);
	P2PSvrSetMemory(MEMORYTYPE_SVR_UDP, (char*)&svrUdpMemoryParam);

	P2PSvrStart(szDeviceID, szPrivateKey, 6 * 1000, 0, 1024 * 1024, 0, &p2pCallback);
	printf("Total Memory:%d\n", g_p2pCamera.m_nSize);

	P2PSvrSetVersion("V1.0.0.1");
	P2PSvrSetTimeOut(6 * 1000);

	P2PSearchSetMemory((char*)0, 1032);
	CP2PSearchCallback searchCallback;
	searchCallback.m_searchDataCB = OnSearchData;
	searchCallback.m_context = 0;
	P2PSearchStart(szDeviceID, 1024, &searchCallback);
	P2PSearchSetLocalAddr((char*)"0.0.0.0", 9000);
	P2PSearchSetUserAddr(8500);
	P2PSearchSetLocalName("My Camera", strlen("My Camera") + 1);

	CreateRingBuffer(&g_p2pCamera.m_ringBufferIn, g_p2pCamera.m_msgInBuffer, MSGINBUFFERSIZE);
	
	{
		pthread_t pid;
		pthread_mutexattr_t attr;
		pthread_attr_t pattr;
		pthread_mutexattr_init(&attr);
		pthread_mutexattr_settype(&attr, PTHREAD_MUTEX_RECURSIVE);
		pthread_mutex_init(&g_p2pCamera.m_lockMsg, &attr);
		pthread_mutexattr_destroy(&attr);
		pthread_attr_init(&pattr);
		pthread_attr_setdetachstate(&pattr, PTHREAD_CREATE_DETACHED);
		if(pthread_create(&pid, &pattr, thread_msg, NULL)!=0)
		{
			perror("pthread_create pid");
			return -1;
		}
		pthread_attr_destroy(&pattr);
	}

	return 0;
}

int p2p_camera_set_local_addr(char* szLocalIP)
{
	P2PSvrSetLocalAddr((char*)szLocalIP, 6800);
	return 0;
}

int p2p_camera_set_server_addr(char* szServerIP, int nServerPort)
{
	P2PSvrSetServerInfo(0, szServerIP, nServerPort, 0);
	return 0;
}

int p2p_camera_stop()
{
	CleanGlobalMemory();
	return 0;
}


