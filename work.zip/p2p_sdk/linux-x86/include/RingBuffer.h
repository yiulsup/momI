#ifndef RINGBUFFER_H
#define RINGBUFFER_H

typedef struct _struct_ring_buffer
{
	unsigned char* m_szBuffer; 
	int m_nBufSize;
	int m_pos;	
	int m_posEnd;
	int m_length;
}CRingBuffer;

#ifdef __cplusplus
extern "C"
{
#endif

int CreateRingBuffer(CRingBuffer* ringBuf, unsigned char* buffer, unsigned int nBufSize);
int DeleteRingBuffer(CRingBuffer* ringBuf);

int PushPacket1(CRingBuffer* ringBuf, char* data1, int length1);
int PushPacket2(CRingBuffer* ringBuf, char* data1, int length1, char* data2, int length2);
int PopPacket1(CRingBuffer* ringBuf, char* data);
int PopPacket2(CRingBuffer* ringBuf);
int FrontPacket1(CRingBuffer* ringBuf, char* data);
int FrontPacket2(CRingBuffer* ringBuf, char* data1, int length1, char* data2);

#ifdef __cplusplus
};
#endif

#endif