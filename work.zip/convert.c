
#include "stdio.h"
#include "string.h"
#include "stdlib.h"

static short nRefTemp1 = 256; // 4803
static short nRefTemp2 = 275; // 4804
static short nRefTemp3 = 254; // 4805

float convert(short, short, short, short);
float after_convert(short, short, short, short);
short max(void);
float temp[80][60];
float actual_temp[80][60];
float bodytemp[60][60];

typedef struct coordi {
	int x;
	int y;
} t_coordi;

t_coordi blackbody_max(void);
t_coordi xy;

void main(void) 
{
	short raw[80][60];

	for (int i=0; i<80; i++) 
		for (int j=0; j<60; j++) 
		{
			temp[i][j] = convert(raw[i][j], nRefTemp1, nRefTemp2, nRefTemp3);
		}

	for (int i=0; i<20; i++) 
		for (int j=0; j<60; j++) {
			xy = blackbody_max();
		}

	for (int i=0; i<80; i++) 
		for (int j=0; j<60; j++) 
		{
			actual_temp[i][j] = after_convert(temp[i][j], nRefTemp1, nRefTemp2, nRefTemp3);
		}

	for (int i=20; i<80; i++) 
		for (int j=0; j<60; j++) {

			bodytemp[i][j] = actual_temp[i][j];
		}

	short bodytemp_max = max();


}

float convert(short nPixelValue, short nRefTemp1, short nRefTemp2, short nRefTemp3)
{
	float fCodePerOneDegree = (float)(nRefTemp2 - nRefTemp1);
	float nSlope = 20.0f / fCodePerOneDegree;
	float nReturn = (float)(nPixelValue - nRefTemp1);

	if ((nRefTemp3 > 150)) {
		nReturn = (nSlope * nReturn) + 25;
							}
	else {
		nReturn = (nSlope * nReturn) + nRefTemp3;
	}

	return nReturn = nReturn * 0.98f;

}

float after_convert(short nReturn, short nRefTemp1, short nRefTemp2, short nRefTemp3)
{
	int x = xy.x;
	int y = xy.y;

	float fBlackbodyPointTemp = temp[x][y];
	float m_fBlackbodyDelta = 37.0 - fBlackbodyPointTemp;
	float m_fCalibration = 0.0;

        	
	float realtemp = nReturn + m_fBlackbodyDelta + m_fCalibration;

	return realtemp = nReturn + m_fBlackbodyDelta + m_fCalibration;
}

short max(void) 
{
	short m_fMaxVal = 0;

	for (int i=20; i<80; i++)
		for (int j=0; j<60; j++)
		{
			if (bodytemp[i][j] > m_fMaxVal) {
				m_fMaxVal = bodytemp[i][j];
			}
		}
}

t_coordi blackbody_max(void) 
{
	short m_fMaxVal = 0;
	int x = 0;
	int y = 0;
	t_coordi tmp;

	for (int i=0; i<20; i++)
		for (int j=0; j<60; j++)
		{
			if (bodytemp[i][j] > m_fMaxVal) {
				m_fMaxVal = bodytemp[i][j];
			 	tmp.x = i;
				tmp.y = j;

			}
		}
	return tmp;

}
