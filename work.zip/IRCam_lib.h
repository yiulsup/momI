#ifndef __IRCAM_LIB_H__
#define __IRCAM_LIB_H__

extern short SK_IRCAM_getBodyTemp(unsigned char * raw_data, int len);

#endif